import './globals.css';

export const metadata = {
  title: 'NextWatch - Your AI Movie Guide',
  description: 'Personalized movie recommendations and ratings',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}