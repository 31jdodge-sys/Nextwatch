"use client";
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { X, Play, CheckCircle2, Star, ThumbsUp, Shield, Info } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MovieDetailsModal({ movie, onClose }) {
  const [rating, setRating] = useState(5);
  const [interest, setInterest] = useState(5);
  const [isWatched, setIsWatched] = useState(false);
  const [otherRatings, setOtherRatings] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Disable body scroll
    document.body.style.overflow = 'hidden';
    fetchExistingRatings();
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [movie.id]);

  const fetchExistingRatings = async () => {
    const { data } = await supabase
      .from('user_ratings')
      .select('rating, interest_rate, is_watched')
      .eq('movie_id', movie.id.toString());
    
    if (data) setOtherRatings(data);

    const { data: { user } } = await supabase.auth.getUser();
    if (user && data) {
      const userRating = data.find(r => r.user_id === user.id);
      if (userRating) {
        setRating(userRating.rating);
        setInterest(userRating.interest_rate);
        setIsWatched(userRating.is_watched);
      }
    }
  };

  const handleSaveRating = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      alert("Please sign in to rate");
      setLoading(false);
      return;
    }

    const ratingData = {
      user_id: user.id,
      movie_id: movie.id.toString(),
      title: movie.title || movie.name,
      poster_path: movie.poster_path,
      rating: rating,
      interest_rate: interest,
      is_watched: isWatched,
      updated_at: new Date()
    };

    const { error } = await supabase
      .from('user_ratings')
      .upsert(ratingData, { onConflict: 'user_id,movie_id' });

    if (error) {
      console.error(error);
      alert("Error saving rating");
    } else {
      alert("Rating saved!");
    }
    setLoading(false);
  };

  const averageRating = otherRatings.length > 0 
    ? (otherRatings.reduce((acc, curr) => acc + curr.rating, 0) / otherRatings.length).toFixed(1)
    : "N/A";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/90 backdrop-blur-md" 
        onClick={onClose}
      />
      
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-[#1c1c21] w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-[2.5rem] relative shadow-2xl custom-scrollbar"
        onClick={e => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          className="absolute right-6 top-6 z-10 bg-black/50 hover:bg-black/70 p-2 rounded-full text-white transition-colors"
        >
          <X size={24} />
        </button>

        <div className="grid md:grid-cols-5 gap-0">
          {/* Left Column: Media */}
          <div className="md:col-span-2 relative">
            <img 
              src={`https://image.tmdb.org/t/p/w780${movie.poster_path}`} 
              className="w-full h-full object-cover"
              alt={movie.title}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-[#1c1c21] hidden md:block"></div>
          </div>

          {/* Right Column: Content */}
          <div className="md:col-span-3 p-8 md:p-12 flex flex-col gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-red-600/20 text-red-500 text-xs font-bold px-3 py-1 rounded-full border border-red-500/20">
                  MOVIE
                </span>
                <span className="flex items-center gap-1 text-yellow-500 font-bold">
                  <Star size={16} fill="currentColor" />
                  {movie.vote_average?.toFixed(1)} TMDB
                </span>
              </div>
              <h2 className="text-4xl font-bold mb-4">{movie.title || movie.name}</h2>
              <p className="text-gray-400 leading-relaxed text-lg line-clamp-4">
                {movie.overview}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center justify-center gap-2 bg-white text-black font-bold py-4 rounded-2xl hover:scale-[1.02] transition-transform">
                <Play size={20} fill="currentColor" /> Watch Trailer
              </button>
              <button 
                onClick={() => setIsWatched(!isWatched)}
                className={`flex items-center justify-center gap-2 font-bold py-4 rounded-2xl border transition-all ${isWatched ? 'bg-green-600/20 text-green-500 border-green-500/30' : 'bg-white/5 text-white border-white/10 hover:bg-white/10'}`}
              >
                <CheckCircle2 size={20} /> {isWatched ? 'Watched' : 'Mark Watched'}
              </button>
            </div>

            <div className="bg-white/5 rounded-3xl p-6 space-y-6">
              <h3 className="font-bold flex items-center gap-2">
                <Star className="text-red-500" size={18} /> Rate this title
              </h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-sm text-gray-400 font-medium">Your Rating</label>
                    <span className="text-red-500 font-bold">{rating}/10</span>
                  </div>
                  <input 
                    type="range" min="1" max="10" step="1"
                    className="w-full accent-red-600 h-2 bg-black/40 rounded-lg appearance-none cursor-pointer"
                    value={rating}
                    onChange={(e) => setRating(parseInt(e.target.value))}
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-sm text-gray-400 font-medium">Interest Level</label>
                    <span className="text-red-500 font-bold">{interest}/10</span>
                  </div>
                  <input 
                    type="range" min="1" max="10" step="1"
                    className="w-full accent-red-600 h-2 bg-black/40 rounded-lg appearance-none cursor-pointer"
                    value={interest}
                    onChange={(e) => setInterest(parseInt(e.target.value))}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-white/5 pt-6">
                <div className="flex flex-col">
                  <span className="text-xs text-gray-500 uppercase tracking-wider">Community Avg</span>
                  <span className="text-xl font-bold">{averageRating}</span>
                </div>
                <button 
                  onClick={handleSaveRating}
                  disabled={loading}
                  className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-xl transition-all disabled:opacity-50"
                >
                  {loading ? 'Saving...' : 'Submit Rating'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}