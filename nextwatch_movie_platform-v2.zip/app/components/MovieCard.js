"use client";
import { Star, ShieldAlert } from 'lucide-react';

export default function MovieCard({ movie, onClick }) {
  // Helper to get a random/simulated "preset" age rating if TMDB doesn't have it easily
  const getAgeRating = () => {
    const ratings = ['G', 'PG', 'PG-13', 'R', '18+'];
    return ratings[movie.id % ratings.length];
  };

  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer flex flex-col"
    >
      {/* Age Rating - Strictly above the title and image */}
      <div className="flex items-center gap-1.5 text-[10px] font-bold tracking-widest text-red-500 uppercase mb-2 ml-1">
        <ShieldAlert size={12} />
        <span>Rated: {getAgeRating()}</span>
      </div>

      <div className="relative aspect-[2/3] rounded-[2rem] overflow-hidden mb-4 movie-bubble shadow-xl ring-1 ring-white/10">
        <img 
          src={movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=500&h=750&fit=crop'} 
          alt={movie.title || movie.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
          <div className="flex items-center gap-1 text-yellow-500 mb-1">
            <Star size={14} fill="currentColor" />
            <span className="text-sm font-bold">{movie.vote_average?.toFixed(1)}</span>
          </div>
          <button className="bg-white text-black text-xs font-bold py-2 px-4 rounded-full w-fit">
            View Details
          </button>
        </div>
      </div>

      <div className="px-2">
        <h3 className="text-white font-semibold text-lg leading-tight line-clamp-1 group-hover:text-red-500 transition-colors">
          {movie.title || movie.name}
        </h3>
        <p className="text-gray-500 text-sm mt-1">
          {new Date(movie.release_date || movie.first_air_date).getFullYear() || 'TBA'}
        </p>
      </div>
    </div>
  );
}