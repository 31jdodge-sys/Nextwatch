"use client";
import { useState } from 'react';
import { Search, Home, Film, Tv, Settings, LogOut, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useRouter, useSearchParams } from 'next/navigation';

export default function Sidebar() {
  const [search, setSearch] = useState('');
  const [isLocked, setIsLocked] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleSearch = (e) => {
    if (e.key === 'Enter' && search.trim() && !isLocked) {
      setIsLocked(true);
      router.push(`/dashboard?q=${encodeURIComponent(search)}`);
    }
  };

  const clearSearch = () => {
    setIsLocked(false);
    setSearch('');
    router.push('/dashboard');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  return (
    <aside className="w-80 h-full bg-[#16161a] border-r border-white/5 p-8 flex flex-col">
      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="bg-red-600 p-2 rounded-xl">
          <Film size={24} className="text-white" />
        </div>
        <h1 className="text-2xl font-black tracking-tight text-white">NextWatch</h1>
      </div>

      <div className="space-y-8 flex-1">
        {/* Search Input - With Lock Feature */}
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block px-2">Discovery</label>
          <div className="relative group">
            <Search className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${isLocked ? 'text-red-500' : 'text-gray-500 group-focus-within:text-red-500'}`} size={18} />
            <input 
              type="text"
              placeholder="Search movies..."
              className={`w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-10 focus:outline-none focus:border-red-500 transition-all ${isLocked ? 'opacity-70 cursor-not-allowed border-red-500/50' : ''}`}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={handleSearch}
              disabled={isLocked}
            />
            {isLocked && (
              <button 
                onClick={clearSearch}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
              >
                <Lock size={16} />
              </button>
            )}
          </div>
          {isLocked && <p className="text-[10px] text-red-500 mt-2 px-2 italic">Search locked. Click icon to reset.</p>}
        </div>

        <nav className="space-y-1">
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block px-2">Navigation</label>
          <button 
            onClick={() => router.push('/dashboard')}
            className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${!searchParams.get('q') ? 'bg-red-600 text-white shadow-lg shadow-red-600/20 font-bold' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <Home size={20} />
            Home
          </button>
          <button className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-gray-400 hover:bg-white/5 hover:text-white transition-all">
            <Film size={20} />
            Movies
          </button>
          <button className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-gray-400 hover:bg-white/5 hover:text-white transition-all">
            <Tv size={20} />
            TV Shows
          </button>
        </nav>

        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-3 block px-2">Filter by Genre</label>
          <div className="flex flex-wrap gap-2 px-2">
            {['Action', 'Sci-Fi', 'Horror', 'Comedy'].map(genre => (
              <button key={genre} className="bg-black/40 border border-white/5 text-[11px] font-bold px-4 py-2 rounded-full hover:border-red-500 transition-colors">
                {genre}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="pt-8 mt-8 border-t border-white/5 space-y-2">
        <button className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-gray-400 hover:bg-white/5 hover:text-white transition-all">
          <Settings size={20} />
          Account Settings
        </button>
        <button 
          onClick={handleLogout}
          className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-red-500 hover:bg-red-500/10 transition-all font-bold"
        >
          <LogOut size={20} />
          Sign Out
        </button>
      </div>
    </aside>
  );
}