"use client";
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { History, Star, ChevronRight } from 'lucide-react';

export default function JustWatchedQueue() {
  const [watched, setWatched] = useState([]);

  useEffect(() => {
    fetchWatched();
    
    // Subscribe to changes
    const channel = supabase
      .channel('watched_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'user_ratings' }, () => {
        fetchWatched();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchWatched = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('user_ratings')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_watched', true)
        .order('updated_at', { ascending: false })
        .limit(5);
      
      setWatched(data || []);
    }
  };

  return (
    <aside className="w-80 h-full bg-[#0a0a0c] border-l border-white/5 p-8 hidden xl:flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <History size={20} className="text-red-500" />
          Just Watched
        </h2>
        <span className="text-xs font-bold text-gray-500 bg-white/5 px-2 py-1 rounded-md">
          {watched.length}
        </span>
      </div>

      <div className="space-y-6 flex-1 overflow-y-auto custom-scrollbar pr-2">
        {watched.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 bg-white/5 rounded-3xl border border-dashed border-white/10 text-center p-6">
            <p className="text-gray-500 text-sm">Your queue is empty. Mark some movies as watched!</p>
          </div>
        ) : (
          watched.map((item) => (
            <div key={item.id} className="group cursor-pointer">
              <div className="flex gap-4">
                <div className="w-16 h-24 rounded-2xl overflow-hidden flex-shrink-0 shadow-lg ring-1 ring-white/10">
                  <img 
                    src={`https://image.tmdb.org/t/p/w200${item.poster_path}`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" 
                    alt={item.title} 
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <h4 className="text-white font-bold text-sm line-clamp-1 mb-1 group-hover:text-red-500 transition-colors">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-1 text-yellow-500 text-xs font-bold">
                    <Star size={12} fill="currentColor" />
                    {item.rating}/10
                  </div>
                  <span className="text-[10px] text-gray-500 mt-2 font-medium flex items-center gap-1">
                    Watched {new Date(item.updated_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <button className="mt-8 w-full bg-white/5 hover:bg-white/10 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all group">
        View Full History
        <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
      </button>
    </aside>
  );
}