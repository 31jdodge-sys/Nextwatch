"use client";
import { useState, useEffect, Suspense } from 'react';
import { supabase } from '@/lib/supabase';
import MovieCard from '@/app/components/MovieCard';
import MovieDetailsModal from '@/app/components/MovieDetailsModal';
import { useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';

function DashboardContent() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [userPreferences, setUserPreferences] = useState(null);
  const searchParams = useSearchParams();

  const TMDB_API_KEY = '5d3410294e9f7358a98f484196144e1d'; // Using a public test key for functionality

  useEffect(() => {
    fetchMovies();
    fetchUserPreferences();
  }, [searchParams]);

  const fetchUserPreferences = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();
      setUserPreferences(data);
    }
  };

  const fetchMovies = async () => {
    setLoading(true);
    const query = searchParams.get('q');
    const genre = searchParams.get('genre');
    const rating = searchParams.get('rating');

    let url = '';
    if (query) {
      url = `https://api.themoviedb.org/3/search/multi?api_key=${TMDB_API_KEY}&query=${query}`;
    } else if (genre) {
      url = `https://api.themoviedb.org/3/discover/movie?api_key=${TMDB_API_KEY}&with_genres=${genre}`;
    } else {
      url = `https://api.themoviedb.org/3/movie/popular?api_key=${TMDB_API_KEY}`;
    }

    try {
      const res = await fetch(url);
      const data = await res.json();
      setMovies(data.results || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 pb-32">
      <div className="mb-10">
        <h1 className="text-4xl font-bold text-white mb-2">
          {searchParams.get('q') ? `Search Results for "${searchParams.get('q')}"` : 'Recommended for You'}
        </h1>
        <p className="text-gray-400">Based on your age ratings and preferences</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="aspect-[2/3] bg-white/5 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (
        <motion.div 
          layout
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10"
        >
          {movies.map((movie) => (
            <MovieCard 
              key={movie.id} 
              movie={movie} 
              onClick={() => setSelectedMovie(movie)} 
            />
          ))}
        </motion.div>
      )}

      <AnimatePresence>
        {selectedMovie && (
          <MovieDetailsModal 
            movie={selectedMovie} 
            onClose={() => setSelectedMovie(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<div className="p-8 text-white">Loading...</div>}>
      <DashboardContent />
    </Suspense>
  );
}