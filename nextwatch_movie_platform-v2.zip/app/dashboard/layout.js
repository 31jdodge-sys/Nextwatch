"use client";
import Sidebar from '@/app/components/Sidebar';
import JustWatchedQueue from '@/app/components/JustWatchedQueue';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';

export default function DashboardLayout({ children }) {
  const [user, setUser] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const getUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/');
      } else {
        setUser(session.user);
      }
    };
    getUser();
  }, [router]);

  if (!user) return <div className="min-h-screen bg-[#0a0a0c] flex items-center justify-center text-white">Loading...</div>;

  return (
    <div className="flex h-screen bg-[#0a0a0c] overflow-hidden">
      <Sidebar />
      <main className="flex-1 relative overflow-y-auto custom-scrollbar">
        {children}
      </main>
      <JustWatchedQueue />
    </div>
  );
}